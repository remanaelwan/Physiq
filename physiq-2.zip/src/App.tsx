/**
 * PhysIQ - Apple Award Winning AI-Powered Body Intelligence Platform
 */

import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/layout/Header';
import { Navigation } from './components/layout/Navigation';
import { DashboardView } from './components/dashboard/DashboardView';
import { BodyIntelligenceView } from './components/body/BodyIntelligenceView';
import { NutritionView } from './components/nutrition/NutritionView';
import { WorkoutView } from './components/workout/WorkoutView';
import { AICoachView } from './components/coach/AICoachView';
import { RecoveryView } from './components/recovery/RecoveryView';
import { CommunityView } from './components/community/CommunityView';
import { AppleHealthView } from './components/health/AppleHealthView';

import {
  INITIAL_MUSCLES,
  INITIAL_MEALS,
  INITIAL_TIMELINE,
  INITIAL_APPLE_HEALTH,
  INITIAL_COMMUNITY_PROGRAMS
} from './data/initialData';

import { MuscleInfo, MealItem, CommunityProgram, AppleHealthData } from './types';
import { GlassCard } from './components/common/GlassCard';
import { X, Plus, Sparkles, Utensils } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [muscles, setMuscles] = useState<MuscleInfo[]>(INITIAL_MUSCLES);
  const [meals, setMeals] = useState<MealItem[]>(INITIAL_MEALS);
  const [selectedMuscle, setSelectedMuscle] = useState<MuscleInfo | null>(INITIAL_MUSCLES[0]);
  const [healthData, setHealthData] = useState<AppleHealthData>(INITIAL_APPLE_HEALTH);
  const [timeline, setTimeline] = useState(INITIAL_TIMELINE);
  const [communityPrograms, setCommunityPrograms] = useState<CommunityProgram[]>(INITIAL_COMMUNITY_PROGRAMS);
  const [waterLogMl, setWaterLogMl] = useState<number>(2200);

  const [isSyncingHealth, setIsSyncingHealth] = useState(false);
  const [isQuickMealModalOpen, setIsQuickMealModalOpen] = useState(false);

  // Quick Meal Modal Form State
  const [quickMealName, setQuickMealName] = useState('');
  const [quickMealProtein, setQuickMealProtein] = useState('40');
  const [quickMealCarbs, setQuickMealCarbs] = useState('50');
  const [quickMealCal, setQuickMealCal] = useState('500');

  // Select Muscle
  const handleSelectMuscle = (muscle: MuscleInfo) => {
    setSelectedMuscle(muscle);
  };

  // Log Meal Handler - Instantly Animates Muscle Recovery!
  const handleLogMeal = (newMeal: MealItem) => {
    setMeals(prev => [newMeal, ...prev]);

    // Animate Muscle Recovery Deltas
    const delta = newMeal.isUnhealthy ? -6 : 8;
    setMuscles(prev =>
      prev.map(m => {
        const isTarget = ['chest', 'front_delts', 'triceps', 'quads'].includes(m.id);
        if (isTarget) {
          const newScore = Math.max(10, Math.min(100, m.recoveryScore + delta));
          return {
            ...m,
            recoveryScore: newScore,
            status: newScore >= 80 ? 'recovered' : newScore >= 60 ? 'recovering' : 'needs_recovery'
          };
        }
        return m;
      })
    );

    setIsQuickMealModalOpen(false);
    setQuickMealName('');

    // Trigger celebratory confetti if healthy meal logged
    if (!newMeal.isUnhealthy) {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 }
      });
    }
  };

  // Simulate Meal Impact API Call
  const handleSimulateMealImpact = async (meal: Partial<MealItem>) => {
    try {
      const response = await fetch('/api/ai/nutrition-impact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ meal, currentMuscles: muscles })
      });
      if (!response.ok) throw new Error('Simulation failed');
      return await response.json();
    } catch (e) {
      console.error(e);
      // Fallback response if offline
      const boost = meal.isUnhealthy ? -6 : 8;
      return {
        summary: `Ingesting ${meal.name} triggers amino acid transport to active muscle cells.`,
        overallRecoveryDelta: `${boost > 0 ? '+' : ''}${boost}%`,
        proteinSupport: 'High',
        scientificRationale: 'Essential amino acids stimulate myofibrillar protein synthesis.'
      };
    }
  };

  // Generate AI Coach Plan API Call
  const handleGenerateAICoachPlan = async (prompt: string) => {
    try {
      const response = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          context: {
            lastWorkout: 'Upper Body Push',
            recoveryScore: 84,
            hrvMs: healthData.hrvMs
          }
        })
      });
      if (!response.ok) throw new Error('AI Coach failed');
      return await response.json();
    } catch (e) {
      console.error(e);
      return {
        advice: 'Based on your recent workload and HRV (78ms), I recommend prioritizing 35g protein within 45 mins and maintaining 8 hours of sleep.',
        suggestedActions: [
          'Drink 500ml water with electrolytes',
          'Reduce overhead press load by 10% today',
          'Aim for 8.5h sleep window'
        ],
        adaptiveProgram: 'Upper Body Deload (-10% Volume)'
      };
    }
  };

  // Finish Active Workout Handler
  const handleFinishWorkout = (workoutTitle: string, durationMinutes: number) => {
    // Increase muscle strain/fatigue
    setMuscles(prev =>
      prev.map(m => {
        if (['chest', 'front_delts', 'triceps'].includes(m.id)) {
          const newScore = Math.max(15, m.recoveryScore - 20);
          return {
            ...m,
            recoveryScore: newScore,
            status: 'needs_recovery'
          };
        }
        return m;
      })
    );

    // Confetti Explosion
    confetti({
      particleCount: 120,
      spread: 80,
      origin: { y: 0.6 }
    });
  };

  // Apple Health Sync Simulator
  const handleSyncHealth = () => {
    setIsSyncingHealth(true);
    setTimeout(() => {
      setHealthData(prev => ({
        ...prev,
        hrvMs: Math.min(100, prev.hrvMs + Math.floor(Math.random() * 5) - 2),
        steps: prev.steps + 250,
        lastSyncedTime: 'Just now'
      }));
      setIsSyncingHealth(false);
    }, 1200);
  };

  // Hydration Increment
  const handleAddWater = (amountMl: number) => {
    setWaterLogMl(prev => prev + amountMl);
  };

  // Clone Community Program
  const handleCloneProgram = (p: CommunityProgram) => {
    setActiveTab('workout');
  };

  return (
    <div className="min-h-screen bg-[#07080c] text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Background VisionOS Ambient Mesh Light Gradients */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-cyan-600/10 blur-[140px]" />
        <div className="absolute top-[20%] right-[-10%] w-[45%] h-[45%] rounded-full bg-purple-600/10 blur-[140px]" />
        <div className="absolute bottom-[-10%] left-[20%] w-[50%] h-[50%] rounded-full bg-indigo-600/10 blur-[140px]" />
      </div>

      {/* Glass Sticky Header */}
      <Header
        healthData={healthData}
        onSyncHealth={handleSyncHealth}
        isSyncing={isSyncingHealth}
        activeTab={activeTab}
      />

      {/* Main Content Area */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            muscles={muscles}
            healthData={healthData}
            meals={meals}
            onNavigateToTab={setActiveTab}
            onSelectMuscle={handleSelectMuscle}
            onOpenQuickMealModal={() => setIsQuickMealModalOpen(true)}
            onStartWorkout={() => setActiveTab('workout')}
          />
        )}

        {activeTab === 'body' && (
          <BodyIntelligenceView
            muscles={muscles}
            selectedMuscle={selectedMuscle}
            onSelectMuscle={handleSelectMuscle}
            timeline={timeline}
            onAskCoachAboutMuscle={(muscle) => {
              setActiveTab('coach');
            }}
          />
        )}

        {activeTab === 'nutrition' && (
          <NutritionView
            meals={meals}
            onLogMeal={handleLogMeal}
            muscles={muscles}
            onSimulateMealImpact={handleSimulateMealImpact}
          />
        )}

        {activeTab === 'workout' && (
          <WorkoutView
            muscles={muscles}
            onFinishWorkout={handleFinishWorkout}
          />
        )}

        {activeTab === 'coach' && (
          <AICoachView
            muscles={muscles}
            onGeneratePlan={handleGenerateAICoachPlan}
          />
        )}

        {activeTab === 'recovery' && (
          <RecoveryView
            healthData={healthData}
            onAddWater={handleAddWater}
            waterLogMl={waterLogMl}
          />
        )}

        {activeTab === 'community' && (
          <CommunityView
            programs={communityPrograms}
            onCloneProgram={handleCloneProgram}
          />
        )}

        {activeTab === 'health' && (
          <AppleHealthView
            healthData={healthData}
            onSyncHealth={handleSyncHealth}
            isSyncing={isSyncingHealth}
          />
        )}
      </main>

      {/* VisionOS Floating Navigation Bar */}
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Quick Meal Logging Modal */}
      {isQuickMealModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <GlassCard glowColor="purple" className="w-full max-w-md p-6 relative">
            <button
              onClick={() => setIsQuickMealModalOpen(false)}
              className="absolute top-4 right-4 p-1 rounded-lg bg-slate-900 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 mb-4">
              <Utensils className="w-5 h-5 text-purple-400" />
              <h3 className="text-lg font-black text-white">Quick Log Meal</h3>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Meal Title</label>
                <input
                  type="text"
                  value={quickMealName}
                  onChange={(e) => setQuickMealName(e.target.value)}
                  placeholder="e.g. Protein Smoothie & Berries"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Calories</label>
                  <input
                    type="number"
                    value={quickMealCal}
                    onChange={(e) => setQuickMealCal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-cyan-400 block mb-1">Protein (g)</label>
                  <input
                    type="number"
                    value={quickMealProtein}
                    onChange={(e) => setQuickMealProtein(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-purple-400 block mb-1">Carbs (g)</label>
                  <input
                    type="number"
                    value={quickMealCarbs}
                    onChange={(e) => setQuickMealCarbs(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <button
                onClick={() => {
                  if (!quickMealName) return;
                  handleLogMeal({
                    id: `qm_${Date.now()}`,
                    name: quickMealName,
                    type: 'snack',
                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    calories: parseInt(quickMealCal) || 400,
                    protein: parseInt(quickMealProtein) || 35,
                    carbs: parseInt(quickMealCarbs) || 45,
                    fat: 10,
                    impactScore: 8
                  });
                }}
                className="w-full py-2.5 mt-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
              >
                <Plus className="w-4 h-4" /> Commit Meal & Animate Body Recovery
              </button>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
