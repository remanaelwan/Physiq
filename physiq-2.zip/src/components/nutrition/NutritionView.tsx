import React, { useState } from 'react';
import { GlassCard } from '../common/GlassCard';
import { MealItem, MuscleInfo } from '../../types';
import {
  Utensils,
  Sparkles,
  Zap,
  Droplets,
  Plus,
  Flame,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Check,
  ShieldCheck,
  Bot
} from 'lucide-react';

interface NutritionViewProps {
  meals: MealItem[];
  onLogMeal: (meal: MealItem) => void;
  muscles: MuscleInfo[];
  onSimulateMealImpact: (meal: Partial<MealItem>) => Promise<any>;
}

export const NutritionView: React.FC<NutritionViewProps> = ({
  meals,
  onLogMeal,
  muscles,
  onSimulateMealImpact
}) => {
  // Food Logger Form State
  const [mealName, setMealName] = useState('');
  const [calories, setCalories] = useState('550');
  const [protein, setProtein] = useState('45');
  const [carbs, setCarbs] = useState('60');
  const [fat, setFat] = useState('12');
  const [waterMl, setWaterMl] = useState('500');
  const [isUnhealthy, setIsUnhealthy] = useState(false);

  // Recovery Simulator State
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationResult, setSimulationResult] = useState<any>(null);

  // Quick Preset Meal Selection
  const presets = [
    { name: 'Grilled Chicken, Quinoa & Avocado', cal: 580, p: 48, c: 55, f: 14, water: 500, unhealthy: false },
    { name: 'Whey Isolate Shake + Banana + Oats', cal: 420, p: 38, c: 52, f: 6, water: 400, unhealthy: false },
    { name: 'Double Bacon Cheeseburger & Fries', cal: 1100, p: 35, c: 95, f: 58, water: 200, unhealthy: true },
    { name: 'Salmon Filet, Sweet Potato & Asparagus', cal: 640, p: 42, c: 45, f: 22, water: 400, unhealthy: false }
  ];

  const handleApplyPreset = (p: typeof presets[0]) => {
    setMealName(p.name);
    setCalories(p.cal.toString());
    setProtein(p.p.toString());
    setCarbs(p.c.toString());
    setFat(p.f.toString());
    setWaterMl(p.water.toString());
    setIsUnhealthy(p.unhealthy);
  };

  const handleSimulateBeforeEating = async () => {
    if (!mealName) return;
    setIsSimulating(true);

    const mealData: Partial<MealItem> = {
      name: mealName,
      calories: parseInt(calories) || 500,
      protein: parseInt(protein) || 40,
      carbs: parseInt(carbs) || 50,
      fat: parseInt(fat) || 12,
      waterMl: parseInt(waterMl) || 400,
      isUnhealthy
    };

    const res = await onSimulateMealImpact(mealData);
    setSimulationResult(res);
    setIsSimulating(false);
  };

  const handleCommitLog = () => {
    if (!mealName) return;

    const newMeal: MealItem = {
      id: `m_${Date.now()}`,
      name: mealName,
      type: 'lunch',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      calories: parseInt(calories) || 500,
      protein: parseInt(protein) || 40,
      carbs: parseInt(carbs) || 50,
      fat: parseInt(fat) || 12,
      waterMl: parseInt(waterMl) || 400,
      isUnhealthy,
      impactScore: isUnhealthy ? -6 : 8
    };

    onLogMeal(newMeal);
    setMealName('');
    setSimulationResult(null);
  };

  const totalCal = meals.reduce((a, b) => a + b.calories, 0);
  const totalP = meals.reduce((a, b) => a + b.protein, 0);
  const totalC = meals.reduce((a, b) => a + b.carbs, 0);

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Title Header */}
      <GlassCard glowColor="purple" className="p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-purple-950/80 border border-purple-800/60 text-purple-400">
              <Utensils className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">Nutrition Intelligence & Recovery Simulator</h2>
              <p className="text-xs text-slate-400">Anabolic Protein Synthesis • Glycogen Repletion Engine</p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/80 px-3.5 py-1.5 rounded-full border border-slate-800 text-xs font-bold text-purple-300">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>AI Nutrient-to-Myofibril Simulator</span>
          </div>
        </div>
      </GlassCard>

      {/* Grid: Simulator & Meal Logger Form + Live Impact Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (7 cols): Meal Builder & Simulator Form */}
        <div className="lg:col-span-7 space-y-4">
          <GlassCard className="p-5">
            <h3 className="text-base font-black text-white mb-3 flex items-center justify-between">
              <span>Log or Simulate Meal</span>
              <span className="text-xs font-normal text-slate-400">Select Presets or Custom Food</span>
            </h3>

            {/* Presets Chips */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4">
              {presets.map((p, i) => (
                <button
                  key={i}
                  onClick={() => handleApplyPreset(p)}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    mealName === p.name
                      ? 'bg-purple-950/80 border-purple-500/50 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold truncate">{p.name}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {p.cal} kcal • {p.p}g P / {p.c}g C {p.unhealthy ? '• ⚠️ High Sodium/Fat' : ''}
                  </div>
                </button>
              ))}
            </div>

            {/* Form Inputs */}
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Meal Title</label>
                <input
                  type="text"
                  value={mealName}
                  onChange={(e) => setMealName(e.target.value)}
                  placeholder="e.g. Salmon Filet & Sweet Potato"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-purple-500/80"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div>
                  <label className="text-[11px] text-slate-400 font-medium block mb-1">Calories (kcal)</label>
                  <input
                    type="number"
                    value={calories}
                    onChange={(e) => setCalories(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-cyan-400 font-medium block mb-1">Protein (g)</label>
                  <input
                    type="number"
                    value={protein}
                    onChange={(e) => setProtein(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-purple-400 font-medium block mb-1">Carbs (g)</label>
                  <input
                    type="number"
                    value={carbs}
                    onChange={(e) => setCarbs(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-amber-400 font-medium block mb-1">Fat (g)</label>
                  <input
                    type="number"
                    value={fat}
                    onChange={(e) => setFat(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              {/* Unhealthy Toggle Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="unhealthy-toggle"
                  checked={isUnhealthy}
                  onChange={(e) => setIsUnhealthy(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-800 text-rose-500 focus:ring-0"
                />
                <label htmlFor="unhealthy-toggle" className="text-xs text-slate-300 font-medium cursor-pointer">
                  Mark as High Sodium / Processed / Alcohol (Simulate Recovery Drop)
                </label>
              </div>

              {/* Action Buttons: Simulate BEFORE Eating vs Commit Log */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleSimulateBeforeEating}
                  disabled={isSimulating || !mealName}
                  className="w-full py-2.5 rounded-xl bg-purple-950/80 hover:bg-purple-900/80 border border-purple-700/60 text-purple-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  {isSimulating ? 'Simulating...' : 'Simulate BEFORE Eating'}
                </button>

                <button
                  onClick={handleCommitLog}
                  disabled={!mealName}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-lg shadow-purple-500/20 transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Log Meal & Update Body
                </button>
              </div>
            </div>
          </GlassCard>

          {/* Logged Meals Today List */}
          <GlassCard className="p-5">
            <h3 className="text-base font-black text-white mb-3">Today's Logged Meals</h3>
            <div className="space-y-2.5">
              {meals.map((m) => (
                <div
                  key={m.id}
                  className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-bold text-slate-200">{m.name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {m.time} • {m.calories} kcal • {m.protein}g Protein / {m.carbs}g Carbs
                    </div>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-lg text-xs font-extrabold ${
                      m.isUnhealthy
                        ? 'bg-rose-950 text-rose-400 border border-rose-800/60'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                    }`}
                  >
                    {m.isUnhealthy ? '-6% Recovery' : `+${m.impactScore || 8}% Recovery`}
                  </span>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Right (5 cols): AI Simulation Results Panel */}
        <div className="lg:col-span-5 space-y-4">
          <GlassCard glowColor={isUnhealthy ? 'rose' : 'emerald'} className="p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4 text-purple-400" />
                <h3 className="text-base font-black text-white">AI Recovery Simulation</h3>
              </div>
              <span className="text-[10px] font-bold text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                Live Myofibril Forecast
              </span>
            </div>

            {simulationResult ? (
              <div className="space-y-4 my-3">
                <div className={`p-4 rounded-xl border ${isUnhealthy ? 'bg-rose-950/40 border-rose-800/60' : 'bg-emerald-950/40 border-emerald-800/60'}`}>
                  <div className="text-xs font-bold text-slate-300 mb-1">Predicted Overall Recovery Delta</div>
                  <div className={`text-3xl font-black ${isUnhealthy ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {simulationResult.overallRecoveryDelta || (isUnhealthy ? '-6%' : '+8%')}
                  </div>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                    {simulationResult.summary}
                  </p>
                </div>

                {/* Affected Muscles Delta List */}
                <div className="space-y-2 text-xs">
                  <div className="font-bold text-slate-300">Predicted Muscle Recovery Changes</div>
                  {[
                    { name: 'Chest (Pectorals)', before: 68, after: isUnhealthy ? 62 : 76 },
                    { name: 'Shoulders (Delts)', before: 63, after: isUnhealthy ? 58 : 69 },
                    { name: 'Triceps Brachii', before: 72, after: isUnhealthy ? 66 : 81 },
                    { name: 'Quadriceps', before: 54, after: isUnhealthy ? 48 : 60 }
                  ].map((m, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-950/70 border border-slate-800">
                      <span className="text-slate-200 font-semibold">{m.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400">{m.before}%</span>
                        <ArrowRight className="w-3 h-3 text-slate-500" />
                        <span className={`font-black ${isUnhealthy ? 'text-rose-400' : 'text-emerald-400'}`}>
                          {m.after}% ({isUnhealthy ? '-6%' : '+8%'})
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Scientific Rationale */}
                <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/50 text-xs text-slate-300 space-y-1">
                  <div className="font-bold text-purple-300 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-purple-400" /> Scientific Rationale
                  </div>
                  <p className="leading-relaxed italic">
                    {simulationResult.scientificRationale || 'Protein ingestion initiates mTOR pathway phosphorylation, rapidly reversing exercise-induced muscle protein breakdown.'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-slate-400 space-y-3">
                <Sparkles className="w-8 h-8 text-purple-400/60 mx-auto animate-pulse" />
                <p className="text-xs max-w-xs mx-auto">
                  Click <span className="text-purple-300 font-bold">"Simulate BEFORE Eating"</span> to preview live muscle color updates, protein synthesis rates & tomorrow's readiness before taking a bite!
                </p>
              </div>
            )}

            {/* Disclaimer */}
            <div className="text-[10px] text-slate-500 text-center pt-2 border-t border-slate-800/80">
              *PhysIQ predictions are AI-powered performance estimates based on sports science algorithms, not medical advice.
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};
