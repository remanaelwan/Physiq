import React, { useState, useEffect } from 'react';
import { GlassCard } from '../common/GlassCard';
import { ExerciseLog, MuscleInfo } from '../../types';
import {
  Dumbbell,
  Play,
  CheckCircle2,
  Clock,
  Plus,
  Flame,
  Activity,
  RotateCcw,
  Sparkles,
  Check,
  Zap
} from 'lucide-react';

interface WorkoutViewProps {
  muscles: MuscleInfo[];
  onFinishWorkout: (workoutTitle: string, durationMinutes: number) => void;
}

export const WorkoutView: React.FC<WorkoutViewProps> = ({ muscles, onFinishWorkout }) => {
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [workoutTitle, setWorkoutTitle] = useState('Upper Body Push & Hypertrophy');
  const [seconds, setSeconds] = useState(0);

  // Exercise Logs
  const [exercises, setExercises] = useState<ExerciseLog[]>([
    {
      id: 'ex1',
      name: 'Incline Dumbbell Press',
      targetMuscles: ['chest', 'front_delts', 'triceps'],
      sets: [
        { setNumber: 1, reps: 10, weightKg: 34, rpe: 8, completed: true },
        { setNumber: 2, reps: 10, weightKg: 34, rpe: 8.5, completed: true },
        { setNumber: 3, reps: 8, weightKg: 36, rpe: 9, completed: false }
      ]
    },
    {
      id: 'ex2',
      name: 'Seated Overhead Dumbbell Press',
      targetMuscles: ['front_delts', 'triceps'],
      sets: [
        { setNumber: 1, reps: 10, weightKg: 26, rpe: 8, completed: true },
        { setNumber: 2, reps: 10, weightKg: 28, rpe: 8.5, completed: false },
        { setNumber: 3, reps: 8, weightKg: 28, rpe: 9, completed: false }
      ]
    },
    {
      id: 'ex3',
      name: 'Cable Tricep Rope Pushdown',
      targetMuscles: ['triceps'],
      sets: [
        { setNumber: 1, reps: 12, weightKg: 30, rpe: 8, completed: false },
        { setNumber: 2, reps: 12, weightKg: 32.5, rpe: 8.5, completed: false },
        { setNumber: 3, reps: 10, weightKg: 35, rpe: 9, completed: false }
      ]
    }
  ]);

  // Rest Timer
  const [restSeconds, setRestSeconds] = useState(0);
  const [isResting, setIsResting] = useState(false);

  // Active workout timer clock
  useEffect(() => {
    let interval: any = null;
    if (isSessionActive) {
      interval = setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isSessionActive]);

  // Rest Timer countdown
  useEffect(() => {
    let interval: any = null;
    if (isResting && restSeconds > 0) {
      interval = setInterval(() => {
        setRestSeconds(s => s - 1);
      }, 1000);
    } else if (restSeconds === 0) {
      setIsResting(false);
    }
    return () => clearInterval(interval);
  }, [isResting, restSeconds]);

  const toggleSetComplete = (exerciseId: string, setIndex: number) => {
    setExercises(prev =>
      prev.map(ex => {
        if (ex.id === exerciseId) {
          const updatedSets = [...ex.sets];
          const curr = updatedSets[setIndex];
          updatedSets[setIndex] = { ...curr, completed: !curr.completed };

          // Trigger rest timer on completing a set
          if (!curr.completed) {
            setRestSeconds(90); // 90 seconds default rest
            setIsResting(true);
          }

          return { ...ex, sets: updatedSets };
        }
        return ex;
      })
    );
  };

  const handleAddSet = (exerciseId: string) => {
    setExercises(prev =>
      prev.map(ex => {
        if (ex.id === exerciseId) {
          const lastSet = ex.sets[ex.sets.length - 1] || { reps: 10, weightKg: 20 };
          return {
            ...ex,
            sets: [
              ...ex.sets,
              {
                setNumber: ex.sets.length + 1,
                reps: lastSet.reps,
                weightKg: lastSet.weightKg,
                rpe: 8,
                completed: false
              }
            ]
          };
        }
        return ex;
      })
    );
  };

  const handleFinishSession = () => {
    setIsSessionActive(false);
    onFinishWorkout(workoutTitle, Math.max(1, Math.round(seconds / 60)));
  };

  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Header Banner */}
      <GlassCard glowColor="cyan" className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-cyan-950/80 border border-cyan-800/60 text-cyan-400">
              <Dumbbell className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">{workoutTitle}</h2>
              <p className="text-xs text-slate-400">Hypertrophy Stimulus • Live Muscle Strain Tracker</p>
            </div>
          </div>

          {/* Start / Finish Session Button */}
          {!isSessionActive ? (
            <button
              onClick={() => setIsSessionActive(true)}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all"
            >
              <Play className="w-4 h-4 fill-current" /> Start Active Workout Session
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <div className="px-3.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-cyan-400 font-mono font-black text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400 animate-spin" />
                <span>{formatTime(seconds)}</span>
              </div>
              <button
                onClick={handleFinishSession}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all"
              >
                <CheckCircle2 className="w-4 h-4" /> Finish Session
              </button>
            </div>
          )}
        </div>
      </GlassCard>

      {/* Rest Timer Floating Banner if resting */}
      {isResting && (
        <div className="p-3 rounded-2xl bg-slate-900/90 backdrop-blur-xl border border-cyan-500/50 flex items-center justify-between shadow-2xl animate-pulse">
          <div className="flex items-center gap-2 text-xs text-slate-200">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span>Resting for next set... Optimal ATP recovery window.</span>
          </div>
          <div className="text-base font-black text-cyan-400 font-mono">{restSeconds}s</div>
        </div>
      )}

      {/* Exercise Logger List */}
      <div className="space-y-4">
        {exercises.map((ex) => (
          <GlassCard key={ex.id} className="p-5">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <div>
                <h3 className="text-base font-black text-white">{ex.name}</h3>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[10px] text-slate-400">Target Muscles:</span>
                  {ex.targetMuscles.map((tm) => (
                    <span
                      key={tm}
                      className="px-2 py-0.2 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/60 text-[10px] font-bold uppercase"
                    >
                      {tm}
                    </span>
                  ))}
                </div>
              </div>

              <button
                onClick={() => handleAddSet(ex.id)}
                className="px-3 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold border border-slate-700 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Set
              </button>
            </div>

            {/* Sets Table */}
            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-12 gap-2 text-slate-400 font-bold px-2 text-[10px] uppercase">
                <div className="col-span-2">Set</div>
                <div className="col-span-4">Weight (kg)</div>
                <div className="col-span-4">Reps</div>
                <div className="col-span-2 text-center">Done</div>
              </div>

              {ex.sets.map((s, idx) => (
                <div
                  key={idx}
                  className={`grid grid-cols-12 gap-2 items-center p-2 rounded-xl border transition-all ${
                    s.completed
                      ? 'bg-emerald-950/40 border-emerald-800/50 text-emerald-200'
                      : 'bg-slate-950/60 border-slate-800/80 text-white'
                  }`}
                >
                  <div className="col-span-2 font-bold pl-1">#{s.setNumber}</div>
                  <div className="col-span-4">
                    <input
                      type="number"
                      value={s.weightKg}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setExercises(prev =>
                          prev.map(item =>
                            item.id === ex.id
                              ? {
                                  ...item,
                                  sets: item.sets.map((st, i) => (i === idx ? { ...st, weightKg: val } : st))
                                }
                              : item
                          )
                        );
                      }}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-xs text-white"
                    />
                  </div>
                  <div className="col-span-4">
                    <input
                      type="number"
                      value={s.reps}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0;
                        setExercises(prev =>
                          prev.map(item =>
                            item.id === ex.id
                              ? {
                                  ...item,
                                  sets: item.sets.map((st, i) => (i === idx ? { ...st, reps: val } : st))
                                }
                              : item
                          )
                        );
                      }}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-xs text-white"
                    />
                  </div>
                  <div className="col-span-2 flex justify-center">
                    <button
                      onClick={() => toggleSetComplete(ex.id, idx)}
                      className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                        s.completed
                          ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                          : 'bg-slate-900 border border-slate-700 text-slate-400 hover:border-slate-500'
                      }`}
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};
