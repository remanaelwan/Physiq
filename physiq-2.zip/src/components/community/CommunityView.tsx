import React, { useState } from 'react';
import { GlassCard } from '../common/GlassCard';
import { CommunityProgram } from '../../types';
import { Users, Star, Copy, Heart, Check, Sparkles, Filter, Search } from 'lucide-react';

interface CommunityViewProps {
  programs: CommunityProgram[];
  onCloneProgram: (program: CommunityProgram) => void;
}

export const CommunityView: React.FC<CommunityViewProps> = ({ programs, onCloneProgram }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'workout' | 'meal_plan'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const handleClone = (p: CommunityProgram) => {
    onCloneProgram(p);
    setCopiedId(p.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const filtered = programs.filter(p => {
    if (filterType !== 'all' && p.type !== filterType) return false;
    if (searchQuery && !p.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Title Banner */}
      <GlassCard glowColor="purple" className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-purple-950/80 border border-purple-800/60 text-purple-400">
              <Users className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">PhysIQ Community & Program Marketplace</h2>
              <p className="text-xs text-slate-400">Clone Verified Programs • Pro Athletes & Dietitians</p>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search programs, coaches, or splits..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex gap-1.5">
          {['all', 'workout', 'meal_plan'].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                filterType === t
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {t === 'all' ? 'All' : t === 'workout' ? 'Workouts' : 'Meal Plans'}
            </button>
          ))}
        </div>
      </div>

      {/* Program Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((p) => (
          <GlassCard key={p.id} glowColor="purple" className="p-5 flex flex-col justify-between">
            <div>
              {/* Creator Header */}
              <div className="flex items-center gap-3 mb-3 pb-3 border-b border-slate-800">
                <img
                  src={p.creatorAvatar}
                  alt={p.creatorName}
                  className="w-10 h-10 rounded-full object-cover border-2 border-purple-500/50"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">{p.creatorName}</span>
                    {p.isVerifiedCoach && (
                      <span className="bg-cyan-500 text-slate-950 px-1.5 py-0.2 rounded text-[9px] font-black uppercase">
                        PRO
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400">{p.creatorRole}</div>
                </div>
              </div>

              {/* Title & Description */}
              <h3 className="text-sm font-black text-white mb-1.5">{p.title}</h3>
              <p className="text-xs text-slate-300 mb-3 leading-relaxed">{p.description}</p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {p.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md bg-slate-950 text-slate-400 border border-slate-800 text-[10px] font-semibold"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs font-bold text-slate-300 mb-3 flex items-center justify-between">
                <span>{p.detailsSummary}</span>
                <div className="flex items-center gap-1 text-amber-400">
                  <Star className="w-3.5 h-3.5 fill-current" /> {p.rating}
                </div>
              </div>

              <button
                onClick={() => handleClone(p)}
                className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                  copiedId === p.id
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-500/20'
                }`}
              >
                {copiedId === p.id ? (
                  <>
                    <Check className="w-4 h-4" /> Program Cloned to Engine!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" /> Clone Program to My Engine
                  </>
                )}
              </button>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};
