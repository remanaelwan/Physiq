import React from 'react';
import { Activity, Watch, ShieldCheck, Sparkles, RefreshCw } from 'lucide-react';
import { AppleHealthData } from '../../types';

interface HeaderProps {
  healthData: AppleHealthData;
  onSyncHealth: () => void;
  isSyncing: boolean;
  activeTab: string;
}

export const Header: React.FC<HeaderProps> = ({
  healthData,
  onSyncHealth,
  isSyncing,
  activeTab
}) => {
  return (
    <header className="sticky top-0 z-50 w-full bg-slate-950/80 backdrop-blur-2xl border-b border-slate-800/80 px-4 py-3 transition-all duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* PhysIQ Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="relative group cursor-pointer">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-600 p-[1.5px] shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-500/40 transition-all">
              <div className="w-full h-full bg-slate-950 rounded-[10.5px] flex items-center justify-center font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 text-xl tracking-wider">
                P
              </div>
            </div>
            {/* Glowing active indicator */}
            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-slate-950 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tight text-white font-sans flex items-center gap-1.5">
                Phys<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-400">IQ</span>
              </h1>
              <span className="text-[10px] font-bold tracking-widest px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-400 border border-cyan-800/60 uppercase">
                v2.4 AI
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block font-medium tracking-wide">
              Physical Intelligence Platform
            </p>
          </div>
        </div>

        {/* Live Apple Watch & Apple Health Sync Pill */}
        <div className="flex items-center gap-3">
          <button
            id="sync-health-btn"
            onClick={onSyncHealth}
            disabled={isSyncing}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 hover:bg-slate-800/90 border border-slate-700/80 text-xs font-semibold text-slate-200 transition-all duration-200 hover:border-cyan-500/50 shadow-md group"
          >
            <Watch className={`w-3.5 h-3.5 text-rose-500 ${isSyncing ? 'animate-bounce' : ''}`} />
            <div className="flex items-center gap-1.5">
              <span className="hidden sm:inline text-slate-400">Apple Watch:</span>
              <span className="text-emerald-400 font-bold">{healthData.hrvMs} ms HRV</span>
            </div>
            <RefreshCw className={`w-3 h-3 text-cyan-400 ${isSyncing ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`} />
          </button>

          {/* AI Status Badge */}
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-950/60 border border-purple-800/60 text-purple-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            <span>AI Neural Engine Active</span>
          </div>
        </div>
      </div>
    </header>
  );
};
