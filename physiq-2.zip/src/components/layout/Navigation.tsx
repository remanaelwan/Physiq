import React from 'react';
import {
  Activity,
  Flame,
  Utensils,
  Dumbbell,
  Bot,
  HeartPulse,
  Users,
  Watch
} from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'body', label: '360° Body', icon: Flame, badge: '360°' },
    { id: 'nutrition', label: 'Nutrition', icon: Utensils },
    { id: 'workout', label: 'Workout', icon: Dumbbell },
    { id: 'coach', label: 'AI Coach', icon: Bot, isAi: true },
    { id: 'recovery', label: 'Recovery', icon: HeartPulse },
    { id: 'community', label: 'Community', icon: Users },
    { id: 'health', label: 'Apple Health', icon: Watch }
  ];

  return (
    <nav className="fixed bottom-3 left-1/2 -translate-x-1/2 z-50 w-[96%] max-w-4xl">
      <div className="bg-slate-950/85 backdrop-blur-3xl border border-slate-800/90 rounded-2xl p-1.5 shadow-2xl shadow-black/80 flex items-center justify-around gap-1 overflow-x-auto no-scrollbar">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`relative flex flex-col items-center justify-center px-3 py-2 rounded-xl transition-all duration-300 min-w-[62px] ${
                isActive
                  ? 'bg-gradient-to-b from-cyan-950/80 to-slate-900 border border-cyan-500/40 text-cyan-400 shadow-lg shadow-cyan-500/20 scale-[1.03]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              {tab.badge && (
                <span className="absolute -top-1 -right-0.5 px-1.5 py-0.2 text-[9px] font-black rounded-full bg-cyan-500 text-slate-950 shadow-sm animate-pulse">
                  {tab.badge}
                </span>
              )}
              {tab.isAi && !isActive && (
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-purple-500 animate-ping" />
              )}
              <Icon className={`w-5 h-5 transition-transform duration-300 ${isActive ? 'scale-110 text-cyan-400' : ''}`} />
              <span className="text-[10px] font-semibold tracking-tight mt-1 whitespace-nowrap">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
