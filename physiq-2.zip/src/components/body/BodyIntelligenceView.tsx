import React, { useState } from 'react';
import { BodyModel3D } from '../3d/BodyModel3D';
import { GlassCard } from '../common/GlassCard';
import { MuscleInfo, TimelineEvent } from '../../types';
import {
  Rotate3D,
  Activity,
  Flame,
  ShieldAlert,
  Clock,
  Dumbbell,
  Sparkles,
  ChevronRight,
  Droplets,
  Moon,
  Zap,
  Bot,
  Utensils,
  TrendingUp,
  CheckCircle2,
  Sliders,
  Info
} from 'lucide-react';

interface BodyIntelligenceViewProps {
  muscles: MuscleInfo[];
  selectedMuscle: MuscleInfo | null;
  onSelectMuscle: (muscle: MuscleInfo) => void;
  timeline: TimelineEvent[];
  onAskCoachAboutMuscle: (muscle: MuscleInfo) => void;
}

export const BodyIntelligenceView: React.FC<BodyIntelligenceViewProps> = ({
  muscles,
  selectedMuscle,
  onSelectMuscle,
  timeline,
  onAskCoachAboutMuscle
}) => {
  const [activeView, setActiveView] = useState<'front' | 'front45' | 'left' | 'right' | 'back' | 'top' | 'free'>('front');
  const [timelineIndex, setTimelineIndex] = useState<number>(timeline.length - 1);
  const [isSimulatingMeal, setIsSimulatingMeal] = useState<boolean>(false);
  const [selectedSimMeal, setSelectedSimMeal] = useState<string>('chicken_rice');

  const currentTimelineEvent = timeline[timelineIndex] || timeline[0];

  // Dynamically calculate recovery score multiplier based on timeline slider & simulation
  const timelineMultiplier = (timelineIndex + 1) / timeline.length;
  const simBoost = isSimulatingMeal ? (selectedSimMeal === 'chicken_rice' ? 13 : selectedSimMeal === 'shake' ? 8 : 6) : 0;

  const currentMuscles = muscles.map(m => {
    const baseScore = Math.min(100, Math.round(m.recoveryScore * (0.8 + 0.2 * timelineMultiplier)));
    const boostedScore = isSimulatingMeal && (m.id === 'chest' || m.id === 'front_delts' || m.id === 'triceps')
      ? Math.min(100, baseScore + simBoost)
      : baseScore;

    return {
      ...m,
      recoveryScore: boostedScore
    };
  });

  const activeMuscle = selectedMuscle || currentMuscles[0];

  // Exercises list for recent workout linkage
  const recentWorkoutExercises = [
    { name: 'Barbell Bench Press', primary: 'Chest', secondary: ['Front Delts', 'Triceps'], sets: '4 sets × 8 reps', weight: '102.5 kg' },
    { name: 'Incline Dumbbell Press', primary: 'Chest', secondary: ['Front Delts'], sets: '4 sets × 10 reps', weight: '42.5 kg' },
    { name: 'Cable Fly', primary: 'Chest', secondary: [], sets: '3 sets × 12 reps', weight: '27.5 kg' },
    { name: 'Seated Shoulder Press', primary: 'Front Delts', secondary: ['Triceps'], sets: '4 sets × 8 reps', weight: '62.5 kg' }
  ];

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Workout Linkage Banner Header */}
      <GlassCard className="p-4 border-cyan-500/30">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 shadow-lg shadow-cyan-500/20">
              <Dumbbell className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
                  Automatic AI Linkage Active
                </span>
                <span className="text-xs text-slate-400">Push Day • 75 min • 12,540 kg Volume</span>
              </div>
              <h2 className="text-lg font-black text-white mt-0.5">Workout Biomechanics Linked to 3D Body</h2>
            </div>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full lg:w-auto">
            {recentWorkoutExercises.map((ex, idx) => (
              <div key={idx} className="px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs whitespace-nowrap flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <div>
                  <span className="font-bold text-white">{ex.name}</span>
                  <span className="text-[10px] text-slate-400 block">→ {ex.primary} ({ex.secondary.join(', ') || 'Isolated'})</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Top Controls: 360 Camera Angle Buttons */}
      <GlassCard className="p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-950/80 border border-cyan-800/60 text-cyan-400">
              <Rotate3D className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">360° Anatomical View</h3>
              <p className="text-xs text-slate-400">Apple VisionOS Liquid Glass Shader Engine</p>
            </div>
          </div>

          {/* View Selector Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {[
              { id: 'front', label: 'Front' },
              { id: 'front45', label: 'Front 45°' },
              { id: 'left', label: 'Left Side' },
              { id: 'right', label: 'Right Side' },
              { id: 'back', label: 'Back' },
              { id: 'top', label: 'Top' },
              { id: 'free', label: '360° Free' }
            ].map(v => (
              <button
                key={v.id}
                onClick={() => setActiveView(v.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeView === v.id
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 scale-105'
                    : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Nutrition Effect & Recovery Simulator Bar */}
      <GlassCard glowColor="purple" className="p-4 border-purple-500/30 bg-purple-950/20">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-purple-950/90 border border-purple-500/50 text-purple-300">
              <Utensils className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-purple-400 uppercase tracking-wider">Nutrition Recovery Simulator</span>
                {isSimulatingMeal && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse">
                    Live Simulation Active
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 font-medium">Preview how eating or drinking improves your 3D muscle recovery instantly</p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full lg:w-auto">
            {/* Meal Selector Options */}
            <select
              value={selectedSimMeal}
              onChange={(e) => setSelectedSimMeal(e.target.value)}
              className="bg-slate-950 text-white text-xs font-bold rounded-xl px-3 py-2 border border-purple-500/40 focus:outline-none focus:border-cyan-400"
            >
              <option value="chicken_rice">🍗 Chicken Breast & Rice (+13% Recovery)</option>
              <option value="shake">🥤 Whey Protein Shake (+8% Recovery)</option>
              <option value="water">💧 1.2L Hydration Boost (-4h Recovery Time)</option>
            </select>

            <button
              onClick={() => setIsSimulatingMeal(!isSimulatingMeal)}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 shadow-lg ${
                isSimulatingMeal
                  ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
                  : 'bg-purple-600 hover:bg-purple-500 text-white shadow-purple-600/30'
              }`}
            >
              <Sliders className="w-4 h-4" />
              {isSimulatingMeal ? 'Reset Body' : 'Simulate Meal'}
            </button>
          </div>
        </div>

        {/* Live Delta Progress Display if active */}
        {isSimulatingMeal && (
          <div className="mt-3 pt-3 border-t border-purple-800/40 flex items-center justify-between text-xs bg-purple-950/60 p-3 rounded-xl border border-purple-800/60">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400 animate-bounce" />
              <span className="text-slate-200">
                Simulated Impact on <strong>{activeMuscle.name}</strong>:
              </span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-slate-400 line-through font-bold">{activeMuscle.recoveryScore - simBoost}%</span>
              <span className="text-cyan-400 font-black">→</span>
              <span className="text-emerald-400 font-black text-sm">{activeMuscle.recoveryScore}%</span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-400 text-[10px] font-extrabold border border-emerald-800">
                +{simBoost}% Faster Recovery
              </span>
            </div>
          </div>
        )}
      </GlassCard>

      {/* Main Grid: Interactive 360 Body Canvas + Floating Muscle Analysis Telemetry Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (7 cols): 360° Metallic Silver Body Model Canvas */}
        <div className="lg:col-span-7">
          <GlassCard glowColor="cyan" className="p-2 relative min-h-[560px] flex flex-col justify-between">
            {/* Legend Bar showing exact color mappings */}
            <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between bg-slate-950/80 backdrop-blur-md p-2.5 rounded-xl border border-slate-800/80 text-[11px] font-semibold">
              <div className="flex items-center gap-3 overflow-x-auto no-scrollbar">
                <span className="flex items-center gap-1.5 text-emerald-400 whitespace-nowrap">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500" /> Green (80-100% Recovered)
                </span>
                <span className="flex items-center gap-1.5 text-amber-400 whitespace-nowrap">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-sm shadow-amber-500" /> Yellow (60-79% Recovering)
                </span>
                <span className="flex items-center gap-1.5 text-orange-400 whitespace-nowrap">
                  <span className="w-2.5 h-2.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500" /> Orange (40-59% Fatigued)
                </span>
                <span className="flex items-center gap-1.5 text-rose-400 whitespace-nowrap">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-sm shadow-rose-500" /> Red (Overtrained)
                </span>
                <span className="flex items-center gap-1.5 text-cyan-400 whitespace-nowrap">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 shadow-sm shadow-cyan-500" /> Blue (Resting / Inactive)
                </span>
              </div>
            </div>

            {/* 360 Metallic Graphite Body Model Render */}
            <BodyModel3D
              muscles={currentMuscles}
              selectedMuscleId={activeMuscle.id}
              onSelectMuscle={onSelectMuscle}
              activeView={activeView}
              simulatedMealBoost={isSimulatingMeal}
            />

            {/* Quick Muscle Selector Horizontal Chips */}
            <div className="p-3 bg-slate-950/90 backdrop-blur-xl rounded-xl border border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <span className="text-xs font-bold text-slate-400 whitespace-nowrap pl-1">Tap Muscle:</span>
              {currentMuscles.map(m => (
                <button
                  key={m.id}
                  onClick={() => onSelectMuscle(m)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                    activeMuscle.id === m.id
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/50 shadow-sm scale-105'
                      : 'bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{
                      backgroundColor:
                        m.recoveryScore >= 80 ? '#10b981' :
                        m.recoveryScore >= 60 ? '#eab308' :
                        m.recoveryScore >= 40 ? '#f97316' : '#ef4444'
                    }}
                  />
                  {m.name.split(' ')[0]}
                </button>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Right Column (5 cols): Floating Glass Panel for Muscle Telemetry */}
        <div className="lg:col-span-5 space-y-4">
          <GlassCard glowColor="purple" className="p-5 relative border-purple-500/30">
            {/* Header: Name, Recovery %, Status Tag */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">Target Muscle Telemetry</span>
                <h3 className="text-xl font-black text-white">{activeMuscle.name}</h3>
                <span className="text-xs text-slate-400 mt-0.5 block">{activeMuscle.lastWorkedOut}</span>
              </div>
              <div className="text-right">
                <div className="text-3xl font-black text-white">{activeMuscle.recoveryScore}%</div>
                <span
                  className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wide inline-block mt-1"
                  style={{
                    backgroundColor: activeMuscle.recoveryScore >= 80 ? '#064e3b' : activeMuscle.recoveryScore >= 60 ? '#78350f' : '#7c2d12',
                    color: activeMuscle.recoveryScore >= 80 ? '#34d399' : activeMuscle.recoveryScore >= 60 ? '#fbbf24' : '#fb923c',
                    borderColor: activeMuscle.recoveryScore >= 80 ? '#059669' : activeMuscle.recoveryScore >= 60 ? '#d97706' : '#ea580c'
                  }}
                >
                  {activeMuscle.recoveryScore >= 80 ? 'Fully Recovered' : activeMuscle.recoveryScore >= 60 ? 'Recovering' : 'Fatigued'}
                </span>
              </div>
            </div>

            {/* Readiness & Volume Metrics Grid */}
            <div className="grid grid-cols-2 gap-3 my-4">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="text-[11px] text-slate-400 font-semibold">Muscle Readiness</div>
                <div className="text-lg font-black text-emerald-400">{activeMuscle.readiness}%</div>
                <div className="text-[10px] text-slate-500">Safe for Training</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="text-[11px] text-slate-400 font-semibold">Growth Potential</div>
                <div className="text-lg font-black text-purple-400">{activeMuscle.growthPotential}%</div>
                <div className="text-[10px] text-slate-500">mTOR Activation</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="text-[11px] text-slate-400 font-semibold">Recovery Time Remaining</div>
                <div className="text-lg font-black text-amber-400">{activeMuscle.estimatedRecoveryHours} <span className="text-xs text-slate-400 font-normal">hrs</span></div>
                <div className="text-[10px] text-slate-500">Until 100% Rested</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="text-[11px] text-slate-400 font-semibold">Workout Volume</div>
                <div className="text-lg font-black text-cyan-400">{activeMuscle.weeklyVolumeSets} <span className="text-xs text-slate-400 font-normal">sets</span></div>
                <div className="text-[10px] text-slate-500">{activeMuscle.weeklyVolumeKg.toLocaleString()} kg load</div>
              </div>
            </div>

            {/* Fuel Needed: Protein, Carbs, Water, Sleep */}
            <div className="space-y-2 mb-4 text-xs bg-slate-950/70 p-3.5 rounded-xl border border-slate-800">
              <div className="font-bold text-slate-200 pb-2 border-b border-slate-800/80 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-cyan-400">
                  <Flame className="w-3.5 h-3.5" /> Target Fuel Required
                </span>
                <span className="text-[10px] text-slate-400">Calculated by PhysIQ AI</span>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center pt-1">
                <div>
                  <div className="font-extrabold text-cyan-400 text-sm">{activeMuscle.proteinNeededGrams}g</div>
                  <div className="text-[10px] text-slate-400">Protein</div>
                </div>
                <div>
                  <div className="font-extrabold text-purple-400 text-sm">{activeMuscle.carbsNeededGrams}g</div>
                  <div className="text-[10px] text-slate-400">Carbs</div>
                </div>
                <div>
                  <div className="font-extrabold text-emerald-400 text-sm">{activeMuscle.waterNeededLiters}L</div>
                  <div className="text-[10px] text-slate-400">Water</div>
                </div>
                <div>
                  <div className="font-extrabold text-amber-400 text-sm">{activeMuscle.sleepNeededHours}h</div>
                  <div className="text-[10px] text-slate-400">Sleep</div>
                </div>
              </div>
            </div>

            {/* AI Recommendation & Advice */}
            <div className="p-3.5 rounded-xl bg-purple-950/50 border border-purple-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-purple-300">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>AI Myofibril Recovery Recommendation</span>
                </div>
                <button
                  onClick={() => onAskCoachAboutMuscle(activeMuscle)}
                  className="text-[10px] font-extrabold text-cyan-400 hover:underline flex items-center gap-1"
                >
                  <Bot className="w-3 h-3" /> Ask AI Coach
                </button>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed italic">
                "{activeMuscle.aiAdvice}"
              </p>
            </div>
          </GlassCard>

          {/* AI Insights Explanation Box: WHY recovery changed */}
          <GlassCard className="p-4 border-cyan-500/20 bg-cyan-950/10">
            <div className="flex items-center gap-2 mb-2 text-cyan-400 font-black text-xs uppercase tracking-wider">
              <Info className="w-4 h-4" />
              <span>AI Recovery Insights (Why It Changed)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-2">
              Your <strong>{activeMuscle.name}</strong> recovery score reached <strong>{activeMuscle.recoveryScore}%</strong> due to:
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 text-emerald-400 font-semibold flex items-center gap-1.5">
                <span>+</span> 42g Whey Protein Intake
              </div>
              <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 text-emerald-400 font-semibold flex items-center gap-1.5">
                <span>+</span> 7.8 hrs Deep Sleep
              </div>
              <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 text-emerald-400 font-semibold flex items-center gap-1.5">
                <span>+</span> 2.6L Cellular Hydration
              </div>
              <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 text-emerald-400 font-semibold flex items-center gap-1.5">
                <span>+</span> 18h Elapsed Rest
              </div>
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Body Timeline Scrubber Component */}
      <GlassCard glowColor="cyan" className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h3 className="text-base font-black text-white">Body Recovery Timeline Scrubber</h3>
              <p className="text-xs text-slate-400">Drag scrubber or tap steps to watch recovery happen on the 3D body</p>
            </div>
          </div>
          <span className="text-xs font-bold text-cyan-400 bg-cyan-950/90 px-3 py-1 rounded-full border border-cyan-800/80">
            {currentTimelineEvent.time} • {currentTimelineEvent.label}
          </span>
        </div>

        {/* Interactive Timeline Slider */}
        <div className="space-y-4">
          <input
            type="range"
            min={0}
            max={timeline.length - 1}
            value={timelineIndex}
            onChange={(e) => setTimelineIndex(parseInt(e.target.value))}
            className="w-full h-2.5 bg-slate-900 rounded-lg appearance-none cursor-pointer accent-cyan-400 border border-slate-800"
          />

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
            {timeline.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setTimelineIndex(idx)}
                className={`p-3 rounded-xl border transition-all text-left ${
                  timelineIndex === idx
                    ? 'bg-cyan-950/90 border-cyan-500/60 text-white shadow-lg shadow-cyan-500/20 scale-102'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-extrabold text-cyan-400 text-[10px]">{item.time}</div>
                <div className="font-bold text-slate-200 truncate">{item.label}</div>
                <div className="text-[10px] text-emerald-400 font-bold mt-1">{item.impact}</div>
              </button>
            ))}
          </div>
        </div>
      </GlassCard>
    </div>
  );
};

