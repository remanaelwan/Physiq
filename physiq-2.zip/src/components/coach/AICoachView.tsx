import React, { useState } from 'react';
import { GlassCard } from '../common/GlassCard';
import { AICoachMessage, MuscleInfo } from '../../types';
import { Bot, Send, Sparkles, User, Dumbbell, Utensils, HeartPulse, ShieldCheck, Zap } from 'lucide-react';

interface AICoachViewProps {
  muscles: MuscleInfo[];
  onGeneratePlan: (prompt: string) => Promise<any>;
}

export const AICoachView: React.FC<AICoachViewProps> = ({ muscles, onGeneratePlan }) => {
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const [messages, setMessages] = useState<AICoachMessage[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: 'Greetings. I am your PhysIQ Master AI Coach. I have analyzed your central nervous system readiness, HRV (78ms), and current muscle recovery profiles. Your chest is at 68% readiness, while your biceps are fully primed at 94%. How would you like me to optimize your program today?',
      timestamp: 'Just now',
      suggestedActions: [
        'Adjust upper push volume -15% for optimal recovery',
        'Consume 35g Whey + 5g Creatine within 45 mins',
        'Prioritize 8.5h sleep tonight (Optimal HRV window 10:15 PM)'
      ]
    }
  ]);

  const quickPrompts = [
    'Optimize my workout program based on my 68% chest recovery',
    'Create a high-protein meal plan for fast muscle repair',
    'Why is my hamstring recovery taking over 30 hours?',
    'Suggest a deload protocol for elevated CNS fatigue'
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputPrompt;
    if (!text.trim()) return;

    const userMsg: AICoachMessage = {
      id: `user_${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputPrompt('');
    setIsLoading(true);

    try {
      const res = await onGeneratePlan(text);
      const aiMsg: AICoachMessage = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: res.advice || 'Program successfully adapted based on your biometric intelligence profile.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: res.suggestedActions || [],
        programAdjustment: res.adaptiveProgram
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Top Banner */}
      <GlassCard glowColor="purple" className="p-5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-purple-950/80 border border-purple-800/60 text-purple-400">
            <Bot className="w-6 h-6 animate-bounce" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">PhysIQ AI Master Coach</h2>
            <p className="text-xs text-slate-400">Gemini 3.6 Flash • Sports Science & Adaptive Progression</p>
          </div>
        </div>
      </GlassCard>

      {/* Quick Prompts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {quickPrompts.map((qp, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(qp)}
            className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 text-left text-xs font-semibold text-slate-200 transition-all flex items-center justify-between group"
          >
            <span>{qp}</span>
            <Sparkles className="w-3.5 h-3.5 text-purple-400 opacity-60 group-hover:opacity-100 transition-opacity" />
          </button>
        ))}
      </div>

      {/* Chat History Box */}
      <GlassCard className="p-5 space-y-4 max-h-[520px] overflow-y-auto">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.sender === 'ai' && (
              <div className="w-8 h-8 rounded-xl bg-purple-950 border border-purple-800 flex items-center justify-center text-purple-400 shrink-0">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div className={`max-w-xl space-y-2 ${m.sender === 'user' ? 'items-end' : 'items-start'}`}>
              <div
                className={`p-4 rounded-2xl text-xs leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-cyan-600 text-white rounded-tr-none'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}
              >
                <p>{m.text}</p>

                {m.programAdjustment && (
                  <div className="mt-3 p-2.5 rounded-xl bg-purple-950/60 border border-purple-800/60 font-bold text-purple-300 text-[11px]">
                    ⚡ Program Adaptive Adjustment: {m.programAdjustment}
                  </div>
                )}
              </div>

              {m.suggestedActions && m.suggestedActions.length > 0 && (
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">AI Actionable Recommendations:</span>
                  {m.suggestedActions.map((action, idx) => (
                    <div key={idx} className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-xs text-cyan-300 font-semibold flex items-center gap-2">
                      <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="text-[10px] text-slate-500">{m.timestamp}</div>
            </div>

            {m.sender === 'user' && (
              <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400 shrink-0">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-xs text-purple-400 font-bold p-3">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>PhysIQ AI Engine synthesizing personalized recommendations...</span>
          </div>
        )}
      </GlassCard>

      {/* Input Field */}
      <GlassCard className="p-2 flex items-center gap-2">
        <input
          type="text"
          value={inputPrompt}
          onChange={(e) => setInputPrompt(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Ask PhysIQ AI Coach anything (e.g., 'Generate my leg day plan')..."
          className="w-full bg-transparent px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
        />
        <button
          onClick={() => handleSendMessage()}
          disabled={!inputPrompt.trim() || isLoading}
          className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition-all disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
        </button>
      </GlassCard>
    </div>
  );
};
