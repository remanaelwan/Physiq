import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { MuscleInfo, RecoveryStatus } from '../../types';

interface BodyModel3DProps {
  muscles: MuscleInfo[];
  selectedMuscleId: string | null;
  onSelectMuscle: (muscle: MuscleInfo) => void;
  activeView: 'front' | 'front45' | 'left' | 'right' | 'back' | 'top' | 'free';
  simulatedMealBoost?: boolean;
}

export const BodyModel3D: React.FC<BodyModel3DProps> = ({
  muscles,
  selectedMuscleId,
  onSelectMuscle,
  activeView,
  simulatedMealBoost = false
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const muscleMeshesRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const reqIdRef = useRef<number | null>(null);

  // Mouse / Touch Drag state
  const isDragging = useRef<boolean>(false);
  const previousMousePosition = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const rotationVelocity = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const bodyGroupRef = useRef<THREE.Group | null>(null);

  const [hoveredMuscle, setHoveredMuscle] = useState<MuscleInfo | null>(null);

  // Helper to get status color hex based on recovery score and training status
  const getStatusHexColor = (score: number, isInactive: boolean = false, isOvertrained: boolean = false): number => {
    if (isOvertrained) return 0xef4444; // Overtrained Red Glow
    if (isInactive) return 0x0284c7; // Untrained Blue Glow
    if (score >= 80) return 0x10b981; // Green (Recovered)
    if (score >= 60) return 0xeab308; // Yellow (Recovering)
    if (score >= 40) return 0xf97316; // Orange (Fatigued / Recovery Started)
    return 0xef4444; // Red (High Strain)
  };

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth || 360;
    const height = container.clientHeight || 520;

    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 4.2);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // Lights - VisionOS Premium Studio Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x00f0ff, 1.2);
    dirLight1.position.set(5, 5, 5);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xa855f7, 0.9);
    dirLight2.position.set(-5, -3, 3);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0x10b981, 1.5, 10);
    pointLight.position.set(0, 0, 2);
    scene.add(pointLight);

    // Main 3D Anatomical Body Group
    const bodyGroup = new THREE.Group();
    bodyGroupRef.current = bodyGroup;
    scene.add(bodyGroup);

    // Glassy Base Pedestal
    const pedestalGeo = new THREE.CylinderGeometry(1.2, 1.35, 0.1, 32);
    const pedestalMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e293b,
      metalness: 0.8,
      roughness: 0.2,
      transmission: 0.4,
      transparent: true,
      opacity: 0.7,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1
    });
    const pedestal = new THREE.Mesh(pedestalGeo, pedestalMat);
    pedestal.position.y = -1.6;
    bodyGroup.add(pedestal);

    // Outer Neon Ring on Pedestal
    const ringGeo = new THREE.TorusGeometry(1.25, 0.02, 16, 64);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI / 2;
    ringMesh.position.y = -1.54;
    bodyGroup.add(ringMesh);

    // Core Wireframe Silhouette (Anatomical Humanoid Torso/Limbs Geometry)
    const buildAnatomicalHuman = () => {
      // Group holding all individual muscle meshes
      const muscleMap = new Map<string, THREE.Mesh>();

      // Geometry creation helper for anatomical muscle shapes with silver/graphite base + overlay
      const createMuscleMesh = (
        id: string,
        geometry: THREE.BufferGeometry,
        pos: { x: number; y: number; z: number },
        rot: { x?: number; y?: number; z?: number },
        score: number,
        isWorkedOut: boolean = true
      ) => {
        const overlayHex = getStatusHexColor(score);
        // Base metallic silver color for graphite body
        const baseSilver = 0x475569;

        const material = new THREE.MeshPhysicalMaterial({
          color: isWorkedOut ? overlayHex : baseSilver,
          emissive: isWorkedOut ? overlayHex : 0x1e293b,
          emissiveIntensity: isWorkedOut ? (selectedMuscleId === id ? 0.7 : 0.35) : 0.05,
          metalness: isWorkedOut ? 0.5 : 0.85,
          roughness: 0.2,
          clearcoat: 0.9,
          clearcoatRoughness: 0.1,
          transparent: true,
          opacity: 0.92,
          wireframe: false
        });

        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(pos.x, pos.y, pos.z);
        if (rot.x) mesh.rotation.x = rot.x;
        if (rot.y) mesh.rotation.y = rot.y;
        if (rot.z) mesh.rotation.z = rot.z;

        mesh.userData = { id, score, isWorkedOut };
        bodyGroup.add(mesh);
        muscleMap.set(id, mesh);

        // Add subtle wireframe overlay for VisionOS futuristic look
        const wireGeo = new THREE.WireframeGeometry(geometry);
        const wireMat = new THREE.LineBasicMaterial({
          color: isWorkedOut ? overlayHex : 0x94a3b8,
          transparent: true,
          opacity: isWorkedOut ? 0.25 : 0.1
        });
        const wireMesh = new THREE.LineSegments(wireGeo, wireMat);
        mesh.add(wireMesh);
      };

      // 1. CHEST (Left & Right Pectorals)
      const chestScore = muscles.find(m => m.id === 'chest')?.recoveryScore || 68;
      const pecsGeo = new THREE.SphereGeometry(0.32, 16, 16);
      pecsGeo.scale(1.2, 0.7, 0.5);
      createMuscleMesh('chest', pecsGeo, { x: 0, y: 0.5, z: 0.25 }, {}, chestScore);

      // 2. FRONT DELTOIDS (Shoulders)
      const deltScore = muscles.find(m => m.id === 'front_delts')?.recoveryScore || 63;
      const deltGeoL = new THREE.SphereGeometry(0.2, 16, 16);
      deltGeoL.scale(1.1, 1.2, 0.9);
      createMuscleMesh('front_delts', deltGeoL, { x: -0.48, y: 0.68, z: 0.1 }, { z: -0.2 }, deltScore);

      const deltGeoR = deltGeoL.clone();
      createMuscleMesh('front_delts_r', deltGeoR, { x: 0.48, y: 0.68, z: 0.1 }, { z: 0.2 }, deltScore);

      // 3. TRICEPS
      const triScore = muscles.find(m => m.id === 'triceps')?.recoveryScore || 72;
      const triGeoL = new THREE.CylinderGeometry(0.11, 0.08, 0.42, 12);
      createMuscleMesh('triceps', triGeoL, { x: -0.52, y: 0.38, z: -0.1 }, { z: -0.15 }, triScore);

      const triGeoR = triGeoL.clone();
      createMuscleMesh('triceps_r', triGeoR, { x: 0.52, y: 0.38, z: -0.1 }, { z: 0.15 }, triScore);

      // 4. BICEPS
      const biScore = muscles.find(m => m.id === 'biceps')?.recoveryScore || 94;
      const biGeoL = new THREE.CapsuleGeometry(0.1, 0.28, 8, 12);
      createMuscleMesh('biceps', biGeoL, { x: -0.52, y: 0.38, z: 0.15 }, { z: -0.1 }, biScore);

      const biGeoR = biGeoL.clone();
      createMuscleMesh('biceps_r', biGeoR, { x: 0.52, y: 0.38, z: 0.15 }, { z: 0.1 }, biScore);

      // 5. LATS (Back)
      const latScore = muscles.find(m => m.id === 'lats')?.recoveryScore || 88;
      const latGeo = new THREE.ConeGeometry(0.55, 0.75, 12);
      latGeo.scale(1.1, 1, 0.4);
      createMuscleMesh('lats', latGeo, { x: 0, y: 0.45, z: -0.25 }, { x: Math.PI }, latScore);

      // 6. TRAPS
      const trapScore = muscles.find(m => m.id === 'traps')?.recoveryScore || 85;
      const trapGeo = new THREE.ConeGeometry(0.42, 0.4, 12);
      trapGeo.scale(1.2, 0.9, 0.5);
      createMuscleMesh('traps', trapGeo, { x: 0, y: 0.92, z: -0.12 }, {}, trapScore);

      // 7. CORE / ABS
      const coreScore = muscles.find(m => m.id === 'core')?.recoveryScore || 91;
      const coreGeo = new THREE.BoxGeometry(0.38, 0.55, 0.22);
      createMuscleMesh('core', coreGeo, { x: 0, y: 0.05, z: 0.18 }, {}, coreScore);

      // 8. QUADS (Legs)
      const quadScore = muscles.find(m => m.id === 'quads')?.recoveryScore || 54;
      const quadGeoL = new THREE.CylinderGeometry(0.18, 0.13, 0.65, 12);
      createMuscleMesh('quads', quadGeoL, { x: -0.22, y: -0.55, z: 0.1 }, { z: -0.05 }, quadScore);

      const quadGeoR = quadGeoL.clone();
      createMuscleMesh('quads_r', quadGeoR, { x: 0.22, y: -0.55, z: 0.1 }, { z: 0.05 }, quadScore);

      // 9. HAMSTRINGS
      const hamScore = muscles.find(m => m.id === 'hamstrings')?.recoveryScore || 48;
      const hamGeoL = new THREE.CylinderGeometry(0.17, 0.13, 0.62, 12);
      createMuscleMesh('hamstrings', hamGeoL, { x: -0.22, y: -0.55, z: -0.12 }, { z: -0.05 }, hamScore);

      const hamGeoR = hamGeoL.clone();
      createMuscleMesh('hamstrings_r', hamGeoR, { x: 0.22, y: -0.55, z: -0.12 }, { z: 0.05 }, hamScore);

      // 10. CALVES
      const calfScore = muscles.find(m => m.id === 'calves')?.recoveryScore || 82;
      const calfGeoL = new THREE.CapsuleGeometry(0.11, 0.4, 8, 12);
      createMuscleMesh('calves', calfGeoL, { x: -0.22, y: -1.18, z: -0.02 }, {}, calfScore);

      const calfGeoR = calfGeoL.clone();
      createMuscleMesh('calves_r', calfGeoR, { x: 0.22, y: -1.18, z: -0.02 }, {}, calfScore);

      // Head Placeholder (Futuristic Glass Helmet)
      const headGeo = new THREE.SphereGeometry(0.22, 24, 24);
      const headMat = new THREE.MeshPhysicalMaterial({
        color: 0x38bdf8,
        metalness: 0.9,
        roughness: 0.1,
        transmission: 0.8,
        transparent: true,
        opacity: 0.6
      });
      const headMesh = new THREE.Mesh(headGeo, headMat);
      headMesh.position.y = 1.25;
      bodyGroup.add(headMesh);

      muscleMeshesRef.current = muscleMap;
    };

    buildAnatomicalHuman();

    // Resize Handler
    const handleResize = () => {
      if (!mountRef.current || !rendererRef.current || !cameraRef.current) return;
      const newW = mountRef.current.clientWidth;
      const newH = mountRef.current.clientHeight;
      cameraRef.current.aspect = newW / newH;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newW, newH);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let clock = new THREE.Clock();
    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      if (bodyGroupRef.current) {
        // Inertia damping for smooth momentum after drag
        if (!isDragging.current) {
          bodyGroupRef.current.rotation.y += rotationVelocity.current.y;
          bodyGroupRef.current.rotation.x += rotationVelocity.current.x;

          rotationVelocity.current.y *= 0.92;
          rotationVelocity.current.x *= 0.92;
        }

        // Subtle realistic body breathing & floating animation
        const time = clock.getElapsedTime();
        bodyGroupRef.current.position.y = Math.sin(time * 1.4) * 0.02;

        // Pulse selected muscle mesh, meal boost, or organic breathing recovery pulse
        muscleMeshesRef.current.forEach((mesh, id) => {
          const mat = mesh.material as THREE.MeshPhysicalMaterial;
          const isSelected = selectedMuscleId === id || (selectedMuscleId && id.startsWith(selectedMuscleId));

          if (simulatedMealBoost) {
            mat.emissiveIntensity = 0.55 + Math.sin(time * 6) * 0.35;
          } else if (isSelected) {
            mat.emissiveIntensity = 0.65 + Math.sin(time * 3.5) * 0.3;
          } else {
            // Gentle rhythmic pulsing for recovery overlay
            mat.emissiveIntensity = 0.28 + Math.sin(time * 1.8 + (mesh.position.y * 3)) * 0.12;
          }
        });
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      if (rendererRef.current?.domElement && container.contains(rendererRef.current.domElement)) {
        container.removeChild(rendererRef.current.domElement);
      }
    };
  }, []);

  // Update Muscle Colors when scores change or simulated meal boost triggers
  useEffect(() => {
    muscles.forEach(m => {
      const hex = getStatusHexColor(m.recoveryScore);
      const primaryMesh = muscleMeshesRef.current.get(m.id);
      const rightMesh = muscleMeshesRef.current.get(`${m.id}_r`);

      [primaryMesh, rightMesh].forEach(mesh => {
        if (mesh) {
          const mat = mesh.material as THREE.MeshPhysicalMaterial;
          mat.color.setHex(hex);
          mat.emissive.setHex(hex);
        }
      });
    });
  }, [muscles]);

  // View Preset Animations (Front, Back, Side, Top, Free)
  useEffect(() => {
    if (!bodyGroupRef.current) return;
    const group = bodyGroupRef.current;
    let targetY = 0;
    let targetX = 0;

    switch (activeView) {
      case 'front':
        targetY = 0;
        targetX = 0;
        break;
      case 'front45':
        targetY = Math.PI / 4;
        targetX = 0;
        break;
      case 'left':
        targetY = -Math.PI / 2;
        targetX = 0;
        break;
      case 'right':
        targetY = Math.PI / 2;
        targetX = 0;
        break;
      case 'back':
        targetY = Math.PI;
        targetX = 0;
        break;
      case 'top':
        targetY = 0;
        targetX = Math.PI / 3;
        break;
      case 'free':
        return;
    }

    // Smooth transition
    const duration = 500;
    const startY = group.rotation.y;
    const startX = group.rotation.x;
    const startTime = performance.now();

    const animateView = (time: number) => {
      const elapsed = time - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3); // easeOutCubic

      group.rotation.y = startY + (targetY - startY) * ease;
      group.rotation.x = startX + (targetX - startX) * ease;

      if (progress < 1) {
        requestAnimationFrame(animateView);
      }
    };

    requestAnimationFrame(animateView);
  }, [activeView]);

  // Pointer Event Handlers for 360 rotation & Muscle Selection Raycasting
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isDragging.current = true;
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isDragging.current && bodyGroupRef.current) {
      const deltaX = e.clientX - previousMousePosition.current.x;
      const deltaY = e.clientY - previousMousePosition.current.y;

      const deltaRotY = deltaX * 0.008;
      const deltaRotX = deltaY * 0.008;

      bodyGroupRef.current.rotation.y += deltaRotY;
      bodyGroupRef.current.rotation.x += deltaRotX;

      // Restrict X rotation to avoid flipping upside down
      bodyGroupRef.current.rotation.x = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, bodyGroupRef.current.rotation.x));

      rotationVelocity.current = { x: deltaRotX * 0.5, y: deltaRotY * 0.5 };
      previousMousePosition.current = { x: e.clientX, y: e.clientY };
    } else {
      // Perform hover raycasting
      checkRaycast(e.clientX, e.clientY);
    }
  };

  const handlePointerUp = () => {
    isDragging.current = false;
  };

  const handlePointerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = mountRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const meshes = Array.from(muscleMeshesRef.current.values()) as THREE.Object3D[];
    const intersects = raycaster.intersectObjects(meshes, true);

    if (intersects.length > 0) {
      let rawId: string | undefined;
      for (const hit of intersects) {
        let obj: THREE.Object3D | null = hit.object;
        while (obj) {
          if (obj.userData && typeof obj.userData.id === 'string') {
            rawId = obj.userData.id;
            break;
          }
          obj = obj.parent;
        }
        if (rawId) break;
      }

      if (rawId) {
        const cleanId = rawId.replace('_r', '');
        const found = muscles.find(m => m.id === cleanId);
        if (found) {
          onSelectMuscle(found);
        }
      }
    }
  };

  const checkRaycast = (clientX: number, clientY: number) => {
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = mountRef.current.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const meshes = Array.from(muscleMeshesRef.current.values()) as THREE.Object3D[];
    const intersects = raycaster.intersectObjects(meshes, true);

    if (intersects.length > 0) {
      let rawId: string | undefined;
      for (const hit of intersects) {
        let obj: THREE.Object3D | null = hit.object;
        while (obj) {
          if (obj.userData && typeof obj.userData.id === 'string') {
            rawId = obj.userData.id;
            break;
          }
          obj = obj.parent;
        }
        if (rawId) break;
      }

      if (rawId) {
        const cleanId = rawId.replace('_r', '');
        const found = muscles.find(m => m.id === cleanId);
        setHoveredMuscle(found || null);
      } else {
        setHoveredMuscle(null);
      }
    } else {
      setHoveredMuscle(null);
    }
  };

  return (
    <div className="relative w-full h-[520px] flex items-center justify-center select-none overflow-hidden touch-none">
      {/* 3D WebGL Canvas Container */}
      <div
        ref={mountRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onClick={handlePointerClick}
        className="w-full h-full cursor-grab active:cursor-grabbing relative z-10"
      />

      {/* Floating VisionOS Glass Quick Indicator on Hover */}
      {hoveredMuscle && (
        <div className="absolute top-6 left-1/2 transform -translate-x-1/2 z-20 pointer-events-none transition-all duration-200">
          <div className="px-4 py-2 rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-cyan-500/40 shadow-2xl shadow-cyan-500/20 flex items-center gap-3">
            <span
              className="w-3 h-3 rounded-full animate-pulse"
              style={{
                backgroundColor:
                  hoveredMuscle.recoveryScore >= 80 ? '#10b981' :
                  hoveredMuscle.recoveryScore >= 60 ? '#f59e0b' :
                  hoveredMuscle.recoveryScore >= 40 ? '#f97316' : '#ef4444'
              }}
            />
            <span className="text-sm font-semibold text-white tracking-wide">{hoveredMuscle.name}</span>
            <span className="text-xs font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded-lg border border-cyan-800/60">
              {hoveredMuscle.recoveryScore}%
            </span>
          </div>
        </div>
      )}

      {/* Interactive Drag Hint */}
      <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 z-20 pointer-events-none text-xs text-slate-400/80 flex items-center gap-2 bg-slate-950/60 backdrop-blur-md px-3 py-1 rounded-full border border-slate-800">
        <svg className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '8s' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
        <span>Drag to rotate 360° • Tap muscle for live AI telemetry</span>
      </div>
    </div>
  );
};
