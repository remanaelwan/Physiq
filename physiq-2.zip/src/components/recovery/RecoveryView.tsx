import React, { useState } from 'react';
import { GlassCard } from '../common/GlassCard';
import { AppleHealthData } from '../../types';
import {
  HeartPulse,
  Moon,
  Droplets,
  ShieldCheck,
  Plus,
  Zap,
  Activity,
  AlertCircle,
  TrendingUp,
  Award
} from 'lucide-react';

interface RecoveryViewProps {
  healthData: AppleHealthData;
  onAddWater: (amountMl: number) => void;
  waterLogMl: number;
}

export const RecoveryView: React.FC<RecoveryViewProps> = ({
  healthData,
  onAddWater,
  waterLogMl
}) => {
  const [sleepLogged, setSleepLogged] = useState(true);

  // Confidence Score calculation
  const confidenceScore = sleepLogged ? 97 : 72;

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Title Header */}
      <GlassCard glowColor="emerald" className="p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-950/80 border border-emerald-800/60 text-emerald-400">
              <HeartPulse className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">Recovery Analysis & Biometric Confidence</h2>
              <p className="text-xs text-slate-400">Autonomic Nervous System • HRV & Parasympathetic Readiness</p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-emerald-950/80 px-3.5 py-1.5 rounded-full border border-emerald-800/60 text-emerald-400 text-xs font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>Recovery Confidence: {confidenceScore}%</span>
          </div>
        </div>
      </GlassCard>

      {/* Recovery Confidence Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <GlassCard glowColor="emerald" className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-black text-white">Recovery Confidence Breakdown</h3>
            <span className="text-xs font-extrabold text-emerald-400">{confidenceScore}% Accurate</span>
          </div>

          <div className="space-y-3 text-xs">
            {[
              { label: 'Workout Load & Strain Data', score: 98, status: 'Synced via Apple Watch' },
              { label: 'Nutrition & Macro Synthesis', score: 95, status: 'Logged via PhysIQ Engine' },
              { label: 'Sleep Stages (REM, Deep, Light)', score: sleepLogged ? 96 : 40, status: sleepLogged ? 'Synced via HealthKit' : 'Missing sleep data' },
              { label: 'Hydration & Electrolytes', score: 92, status: `${waterLogMl}ml logged today` },
              { label: 'HRV & Resting Heart Rate', score: 99, status: `${healthData.hrvMs}ms HRV • ${healthData.restingHeartRate} bpm RHR` }
            ].map((item, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                <div className="flex justify-between font-bold text-slate-200 mb-1">
                  <span>{item.label}</span>
                  <span className="text-emerald-400">{item.score}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden mb-1">
                  <div
                    className="h-full bg-emerald-400 rounded-full transition-all duration-500"
                    style={{ width: `${item.score}%` }}
                  />
                </div>
                <div className="text-[10px] text-slate-400">{item.status}</div>
              </div>
            ))}
          </div>

          {!sleepLogged && (
            <div className="mt-4 p-3 rounded-xl bg-amber-950/60 border border-amber-800/60 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-amber-300 font-semibold">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Log sleep duration to boost confidence to 97%</span>
              </div>
              <button
                onClick={() => setSleepLogged(true)}
                className="px-3 py-1 bg-amber-500 text-slate-950 font-black rounded-lg text-[11px]"
              >
                Log Sleep
              </button>
            </div>
          )}
        </GlassCard>

        {/* Hydration Tracker */}
        <GlassCard glowColor="cyan" className="p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Droplets className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-black text-white">Hydration & Fluid Balance</h3>
              </div>
              <span className="text-xs font-bold text-cyan-400">{waterLogMl} / 3000 ml</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 mb-4 text-center">
              <div className="text-3xl font-black text-white">{(waterLogMl / 1000).toFixed(1)} <span className="text-sm font-medium text-slate-400">Liters Logged</span></div>
              <div className="text-xs text-cyan-400 font-semibold mt-1">Cellular Hydration Optimal for Protein Synthesis</div>
            </div>

            {/* Quick Water Logging Buttons */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => onAddWater(250)}
                className="py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-cyan-300 flex items-center justify-center gap-1 transition-all"
              >
                <Plus className="w-3.5 h-3.5" /> 250 ml
              </button>
              <button
                onClick={() => onAddWater(500)}
                className="py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-cyan-300 flex items-center justify-center gap-1 transition-all"
              >
                <Plus className="w-3.5 h-3.5" /> 500 ml
              </button>
              <button
                onClick={() => onAddWater(750)}
                className="py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-cyan-300 flex items-center justify-center gap-1 transition-all"
              >
                <Plus className="w-3.5 h-3.5" /> 750 ml
              </button>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-800/50 text-xs text-slate-300 mt-4">
            <span className="font-bold text-cyan-300">Hydration Tip:</span> Drinking 500ml water with electrolytes right after waking up reduces muscle stiffness by 12%.
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
