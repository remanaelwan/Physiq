import React from 'react';
import { GlassCard } from '../common/GlassCard';
import { AppleHealthData } from '../../types';
import { Watch, Heart, Activity, Moon, Zap, RefreshCw, ShieldCheck, CheckCircle } from 'lucide-react';

interface AppleHealthViewProps {
  healthData: AppleHealthData;
  onSyncHealth: () => void;
  isSyncing: boolean;
}

export const AppleHealthView: React.FC<AppleHealthViewProps> = ({
  healthData,
  onSyncHealth,
  isSyncing
}) => {
  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Title Header */}
      <GlassCard glowColor="rose" className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-rose-950/80 border border-rose-800/60 text-rose-400">
              <Watch className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">Apple Health & Apple Watch Intelligence Hub</h2>
              <p className="text-xs text-slate-400">Real-time HealthKit Pipeline • Electrocardiogram & Photoplethysmography</p>
            </div>
          </div>

          <button
            onClick={onSyncHealth}
            disabled={isSyncing}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-purple-600 hover:from-rose-400 hover:to-purple-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-500/20 transition-all"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Syncing HealthKit...' : 'Sync HealthKit Now'}
          </button>
        </div>
      </GlassCard>

      {/* Device Connection Status Card */}
      <GlassCard className="p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
            <div>
              <div className="text-sm font-black text-white">Apple Watch Ultra 2 Connected</div>
              <div className="text-xs text-slate-400">Continuous Optical Heart Sensor Active • Last Synced: {healthData.lastSyncedTime}</div>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/60 text-xs font-bold flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5" /> Active Sync
          </span>
        </div>
      </GlassCard>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <GlassCard glowColor="rose" className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Heart Rate Variability</span>
            <Heart className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-3xl font-black text-white">{healthData.hrvMs} <span className="text-sm font-normal text-slate-400">ms</span></div>
          <p className="text-xs text-emerald-400 font-bold mt-2">Optimal parasympathetic nervous system tone.</p>
        </GlassCard>

        <GlassCard glowColor="emerald" className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Resting Heart Rate</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-black text-white">{healthData.restingHeartRate} <span className="text-sm font-normal text-slate-400">bpm</span></div>
          <p className="text-xs text-slate-400 mt-2">Superior cardiovascular conditioning baseline.</p>
        </GlassCard>

        <GlassCard glowColor="purple" className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">VO2 Max Estimate</span>
            <Zap className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-3xl font-black text-white">{healthData.vo2Max} <span className="text-sm font-normal text-slate-400">ml/kg/min</span></div>
          <p className="text-xs text-purple-400 font-bold mt-2">Top 5% for age bracket.</p>
        </GlassCard>

        <GlassCard glowColor="cyan" className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Sleep Stages</span>
            <Moon className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-black text-white">{healthData.sleepDurationHours} <span className="text-sm font-normal text-slate-400">hrs</span></div>
          <p className="text-xs text-cyan-400 font-bold mt-2">Deep {healthData.deepSleepPercent}% • REM {healthData.remSleepPercent}%</p>
        </GlassCard>

        <GlassCard glowColor="amber" className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Active Energy Burned</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-black text-white">{healthData.activeEnergyKcal} <span className="text-sm font-normal text-slate-400">kcal</span></div>
          <p className="text-xs text-slate-400 mt-2">Goal: 650 kcal</p>
        </GlassCard>

        <GlassCard className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Body Mass</span>
            <ShieldCheck className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-3xl font-black text-white">{healthData.weightKg} <span className="text-sm font-normal text-slate-400">kg</span></div>
          <p className="text-xs text-emerald-400 font-bold mt-2">-0.4 kg lean recomp this month</p>
        </GlassCard>
      </div>
    </div>
  );
};
