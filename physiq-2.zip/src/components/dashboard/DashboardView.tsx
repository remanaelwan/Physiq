import React from 'react';
import { GlassCard } from '../common/GlassCard';
import { MuscleInfo, AppleHealthData, MealItem } from '../../types';
import {
  Flame,
  Activity,
  Zap,
  Droplets,
  Moon,
  Heart,
  Dumbbell,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  Utensils
} from 'lucide-react';

interface DashboardViewProps {
  muscles: MuscleInfo[];
  healthData: AppleHealthData;
  meals: MealItem[];
  onNavigateToTab: (tab: string) => void;
  onSelectMuscle: (muscle: MuscleInfo) => void;
  onOpenQuickMealModal: () => void;
  onStartWorkout: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  muscles,
  healthData,
  meals,
  onNavigateToTab,
  onSelectMuscle,
  onOpenQuickMealModal,
  onStartWorkout
}) => {
  // Calculate average recovery score
  const avgRecovery = Math.round(
    muscles.reduce((sum, m) => sum + m.recoveryScore, 0) / muscles.length
  );

  // Total macros logged today
  const totalCalories = meals.reduce((sum, m) => sum + m.calories, 0);
  const totalProtein = meals.reduce((sum, m) => sum + m.protein, 0);
  const totalCarbs = meals.reduce((sum, m) => sum + m.carbs, 0);
  const totalFat = meals.reduce((sum, m) => sum + m.fat, 0);

  const targetCalories = 2300;
  const targetProtein = 190;
  const targetCarbs = 290;
  const targetFat = 70;

  return (
    <div className="space-[#12px] space-y-6 pb-28 pt-2">
      {/* Top Banner: Body Intelligence Recovery Score Ring */}
      <GlassCard glowColor="cyan" className="p-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Recovery Circular Metric */}
          <div className="flex items-center gap-6">
            <div className="relative w-28 h-28 flex items-center justify-center">
              {/* Outer Glow Ring */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="stroke-slate-800"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="stroke-cyan-400 transition-all duration-1000 ease-out"
                  strokeWidth="8"
                  strokeDasharray="263.8"
                  strokeDashoffset={263.8 * (1 - avgRecovery / 100)}
                  strokeLinecap="round"
                  fill="transparent"
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-3xl font-black text-white tracking-tight">{avgRecovery}%</span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400">Recovery</span>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black text-white">Body Intelligence</span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 text-xs font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> 97% Confidence
                </span>
              </div>
              <p className="text-xs text-slate-300 max-w-md leading-relaxed">
                Central nervous system readiness is high. Muscle protein synthesis active across chest and shoulders.
              </p>
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => onNavigateToTab('body')}
                  className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-500/25 transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '12s' }} />
                  Launch 360° Body Engine
                </button>
              </div>
            </div>
          </div>

          {/* Quick Muscle Status Matrix */}
          <div className="grid grid-cols-2 gap-2.5 w-full md:w-auto">
            {muscles.slice(0, 4).map(m => (
              <div
                key={m.id}
                onClick={() => {
                  onSelectMuscle(m);
                  onNavigateToTab('body');
                }}
                className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-cyan-500/50 cursor-pointer transition-all flex items-center justify-between gap-3"
              >
                <div>
                  <div className="text-xs font-bold text-slate-200">{m.name.split(' ')[0]}</div>
                  <div className="text-[10px] text-slate-400">{m.status.replace('_', ' ')}</div>
                </div>
                <span
                  className="px-2 py-0.5 rounded-md text-xs font-black"
                  style={{
                    backgroundColor:
                      m.recoveryScore >= 80 ? 'rgba(16, 185, 129, 0.2)' :
                      m.recoveryScore >= 60 ? 'rgba(245, 158, 11, 0.2)' : 'rgba(239, 68, 68, 0.2)',
                    color:
                      m.recoveryScore >= 80 ? '#34d399' :
                      m.recoveryScore >= 60 ? '#fbbf24' : '#f87171'
                  }}
                >
                  {m.recoveryScore}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Grid: Nutrition Intelligence & Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Nutrition Ring & Macro Progress */}
        <GlassCard glowColor="purple" className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-purple-950/80 border border-purple-800/60 text-purple-400">
                <Utensils className="w-4 h-4" />
              </div>
              <h2 className="text-base font-black text-white">Nutrition Intelligence</h2>
            </div>
            <button
              onClick={onOpenQuickMealModal}
              className="text-xs font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1 bg-purple-950/60 px-2.5 py-1 rounded-lg border border-purple-800/60"
            >
              + Log Meal
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <div>
                <div className="text-2xl font-black text-white">{totalCalories} <span className="text-xs font-medium text-slate-400">/ {targetCalories} kcal</span></div>
                <div className="text-xs text-slate-400">Energy & Glycogen Replenishment</div>
              </div>
              <button
                onClick={() => onNavigateToTab('nutrition')}
                className="px-3 py-1.5 rounded-lg bg-purple-900/40 text-purple-300 text-xs font-bold border border-purple-800/50 hover:bg-purple-900/60 transition-all flex items-center gap-1"
              >
                Simulator <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Macro Bars */}
            <div className="space-y-2.5 text-xs">
              <div>
                <div className="flex justify-between font-semibold mb-1">
                  <span className="text-slate-300">Protein (Muscle Repair)</span>
                  <span className="text-cyan-400 font-bold">{totalProtein}g / {targetProtein}g</span>
                </div>
                <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (totalProtein / targetProtein) * 100)}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-semibold mb-1">
                  <span className="text-slate-300">Carbs (Glycogen Stores)</span>
                  <span className="text-purple-400 font-bold">{totalCarbs}g / {targetCarbs}g</span>
                </div>
                <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (totalCarbs / targetCarbs) * 100)}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-semibold mb-1">
                  <span className="text-slate-300">Fats (Hormone Health)</span>
                  <span className="text-amber-400 font-bold">{totalFat}g / {targetFat}g</span>
                </div>
                <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (totalFat / targetFat) * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Biometric Health & Recovery Overview */}
        <GlassCard glowColor="emerald" className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-950/80 border border-emerald-800/60 text-emerald-400">
                <Activity className="w-4 h-4" />
              </div>
              <h2 className="text-base font-black text-white">Apple Health Matrix</h2>
            </div>
            <button
              onClick={() => onNavigateToTab('health')}
              className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              Full Sync <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                <Heart className="w-3.5 h-3.5 text-rose-400" /> HRV (Heart Rate Var)
              </div>
              <div className="text-xl font-black text-white">{healthData.hrvMs} <span className="text-xs text-slate-400 font-medium">ms</span></div>
              <div className="text-[10px] text-emerald-400 font-bold mt-0.5">High Parasympathetic Drive</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                <Moon className="w-3.5 h-3.5 text-indigo-400" /> Sleep Duration
              </div>
              <div className="text-xl font-black text-white">{healthData.sleepDurationHours} <span className="text-xs text-slate-400 font-medium">hrs</span></div>
              <div className="text-[10px] text-cyan-400 font-bold mt-0.5">Deep {healthData.deepSleepPercent}% • REM {healthData.remSleepPercent}%</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" /> Daily Steps
              </div>
              <div className="text-xl font-black text-white">{healthData.steps.toLocaleString()}</div>
              <div className="text-[10px] text-slate-400 font-medium mt-0.5">Goal: 10,000 steps</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                <Droplets className="w-3.5 h-3.5 text-cyan-400" /> Hydration
              </div>
              <div className="text-xl font-black text-white">2.2 <span className="text-xs text-slate-400 font-medium">/ 3.0 L</span></div>
              <div className="text-[10px] text-cyan-400 font-bold mt-0.5">Optimal Cellular Hydration</div>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Today's Adaptive Workout Recommendation */}
      <GlassCard glowColor="cyan" className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h2 className="text-base font-black text-white">Today's AI Workout Program</h2>
            </div>
            <p className="text-xs text-slate-400">Targeting Chest, Shoulders & Triceps with 18 high-yield hypertrophy sets.</p>
          </div>
          <button
            onClick={onStartWorkout}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all"
          >
            <Dumbbell className="w-4 h-4" /> Start Live Workout Session
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">Incline Dumbbell Press</div>
              <div className="text-[10px] text-slate-400">4 Sets • 8-10 Reps • RPE 8</div>
            </div>
            <span className="text-xs font-extrabold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/60">Chest</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">Seated Overhead Press</div>
              <div className="text-[10px] text-slate-400">3 Sets • 10 Reps • RPE 7.5</div>
            </div>
            <span className="text-xs font-extrabold text-purple-400 bg-purple-950/80 px-2 py-0.5 rounded border border-purple-800/60">Shoulders</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">Cable Tricep Pushdown</div>
              <div className="text-[10px] text-slate-400">4 Sets • 12 Reps • RPE 8.5</div>
            </div>
            <span className="text-xs font-extrabold text-indigo-400 bg-indigo-950/80 px-2 py-0.5 rounded border border-indigo-800/60">Triceps</span>
          </div>
        </div>
      </GlassCard>
    </div>
  );
};
