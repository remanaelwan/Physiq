import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  glowColor?: 'cyan' | 'purple' | 'emerald' | 'amber' | 'rose' | 'none';
  onClick?: () => void;
  id?: string;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className = '',
  glowColor = 'none',
  onClick,
  id
}) => {
  const glowStyles = {
    cyan: 'border-cyan-500/30 hover:border-cyan-400/50 shadow-[0_0_25px_rgba(6,182,212,0.12)]',
    purple: 'border-purple-500/30 hover:border-purple-400/50 shadow-[0_0_25px_rgba(168,85,247,0.12)]',
    emerald: 'border-emerald-500/30 hover:border-emerald-400/50 shadow-[0_0_25px_rgba(16,185,129,0.12)]',
    amber: 'border-amber-500/30 hover:border-amber-400/50 shadow-[0_0_25px_rgba(245,158,11,0.12)]',
    rose: 'border-rose-500/30 hover:border-rose-400/50 shadow-[0_0_25px_rgba(244,63,94,0.12)]',
    none: 'border-slate-800/80 hover:border-slate-700/80 shadow-lg shadow-black/40'
  };

  return (
    <div
      id={id}
      onClick={onClick}
      className={`relative overflow-hidden rounded-2xl bg-gradient-to-b from-slate-900/90 via-slate-900/70 to-slate-950/90 backdrop-blur-2xl border transition-all duration-300 ${glowStyles[glowColor]} ${onClick ? 'cursor-pointer hover:scale-[1.01] active:scale-[0.99]' : ''} ${className}`}
    >
      {/* Specular glass highlight reflection line at top border */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
      {children}
    </div>
  );
};
