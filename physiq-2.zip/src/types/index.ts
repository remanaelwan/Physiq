export type RecoveryStatus = 'recovered' | 'recovering' | 'needs_recovery' | 'fatigued' | 'inactive';

export interface MuscleInfo {
  id: string;
  name: string;
  category: 'chest' | 'back' | 'shoulders' | 'arms' | 'core' | 'legs';
  recoveryScore: number; // 0 - 100
  status: RecoveryStatus;
  readiness: number; // %
  growthPotential: number; // %
  estimatedRecoveryHours: number;
  weeklyVolumeSets: number;
  weeklyVolumeKg: number;
  lastWorkedOut: string;
  proteinNeededGrams: number;
  carbsNeededGrams: number;
  caloriesNeeded: number;
  waterNeededLiters: number;
  sleepNeededHours: number;
  micronutrients: string[];
  riskLevel: 'Low' | 'Moderate' | 'Elevated' | 'High';
  fatigueScore: number; // 0 - 10
  recommendedExercises: string[];
  aiAdvice: string;
  coordinates: { x: number; y: number; z: number }; // 3D anchor position
  positionSide: 'front' | 'back' | 'both';
}

export interface MealItem {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  waterMl?: number;
  time: string;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'pre_workout' | 'post_workout';
  isUnhealthy?: boolean;
  impactScore?: number; // e.g. +8%
  affectedMuscles?: { muscleId: string; deltaPercent: number }[];
}

export interface ExerciseLog {
  id: string;
  name: string;
  targetMuscles: string[];
  sets: {
    setNumber: number;
    reps: number;
    weightKg: number;
    rpe?: number;
    completed: boolean;
  }[];
}

export interface WorkoutSession {
  id: string;
  title: string;
  category: string;
  durationMinutes: number;
  caloriesBurned: number;
  date: string;
  exercises: ExerciseLog[];
  musclesWorked: string[];
  overallFatigueGenerated: number;
}

export interface TimelineEvent {
  id: string;
  time: string; // e.g. "07:30 AM"
  label: string;
  type: 'workout' | 'meal' | 'hydration' | 'sleep' | 'supplement';
  impact: string; // e.g. "+5% Recovery"
  recoveryScoreAfter: number;
  hydrationAfter: number;
  description: string;
}

export interface CommunityProgram {
  id: string;
  title: string;
  creatorName: string;
  creatorAvatar: string;
  creatorRole: string;
  type: 'workout' | 'meal_plan';
  rating: number;
  clonesCount: number;
  likesCount: number;
  description: string;
  tags: string[];
  detailsSummary: string;
  isVerifiedCoach?: boolean;
}

export interface AppleHealthData {
  heartRateBpm: number;
  restingHeartRate: number;
  hrvMs: number;
  sleepDurationHours: number;
  deepSleepPercent: number;
  remSleepPercent: number;
  steps: number;
  activeEnergyKcal: number;
  vo2Max: number;
  weightKg: number;
  lastSyncedTime: string;
  isWatchConnected: boolean;
}

export interface AICoachMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  programAdjustment?: string;
}
